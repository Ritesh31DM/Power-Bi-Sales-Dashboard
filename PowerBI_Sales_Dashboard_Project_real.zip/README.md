# Power BI Sales Dashboard – Interactive Sales Insights

## Description
Developed a comprehensive **Power BI Sales Dashboard** analyzing regional and product-wise sales, revenue trends, and key performance metrics. The dashboard features interactive **slicers and filters** for dynamic analysis, helping stakeholders quickly identify top-performing products, high-revenue regions, and sales patterns.

**Tools Used:** Power BI Desktop, CSV dataset  
**Impact:** Enables decision-makers to **track sales trends, optimize product strategy, and improve revenue forecasting**.

## Dashboard Features
- KPIs: Total Sales, Total Profit, Total Quantity
- Sales by Region (Map/Bar Chart)
- Top Products by Sales
- Monthly Sales Trend
- Profit Analysis
- Interactive Slicers: Region, Product, Date

## Instructions
1. Open Power BI Desktop and create a new report.
2. Import the CSV from the dataset folder.
3. Recreate visuals as per the README or use the provided PBIX (if available).
4. Replace screenshots with actual ones after building the PBIX.

## Screenshots
Screenshots are available in the `screenshots/` folder.
